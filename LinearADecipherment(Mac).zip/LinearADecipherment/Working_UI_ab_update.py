from PyQt5 import QtCore
from PyQt5.QtGui import QPixmap, QFontDatabase, QImage, QFont, QPalette, QBrush
from PyQt5.QtWidgets import QApplication, QLabel, QMainWindow, QPushButton, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem, QGridLayout, QApplication, QFileDialog, QSizePolicy
from PyQt5.QtCore import QSize, Qt, QRect
from functools import *
import sys
import pandas as pd
import os
from csv import reader
import openpyxl
from openpyxl.styles import Font
#from PyQt5.QtWidgets import *
#from PyQt5.QtGui import *


#--------

##Importing of raw data from CSV files under misc folder
df1 = pd.read_csv("misc/Identical_matches.csv",header=None,names = ["Row","Matches","Actual_Row","Original_Word","Source"])
Actual_Row = df1.loc[:,"Actual_Row"]
Original_Word = df1.loc[:,"Original_Word"]
Source = df1.loc[:,"Source"]
Matches = df1.loc[:,"Matches"]

df2 = pd.read_csv('misc/Numberedstr_matches.csv',header=None, names=["Index","Identical_matches","Numbered_str","Row"])
Identical_matches = df2.loc[:,"Identical_matches"]
Numbered_str = df2.loc[:,"Numbered_str"]
Row = df2.loc[:,"Row"]

df15 = pd.read_csv("misc/Complied_Gorilla.csv",header=None,names=["R1","R2","R3","R4","R5","R6","R7","R8","R9","R10","R11","LOWER"])
LinearA_source = df15.loc[:,"R2"]
LinearA = df15.loc[:,"LOWER"]

LinearA_Without_Gaps = df15.loc[:,"R7"]

df17 = pd.read_csv("Updated_results/Anatolia_updatedresults.csv",header=None,names=["Identical Matches","Anatolia_Words","Linear A Word","Source"])
AnatoliaUpdatedResults_matches = df17.loc[:,"Identical Matches"]
AnatoliaUpdatedResults_word = df17.loc[:,"Anatolia_Words"] 
AnatoliaUpdatedResults_LAword = df17.loc[:,"Linear A Word"] 
AnatoliaUpdatedResults_Source = df17.loc[:,"Source"] 

df18 = pd.read_csv("Updated_results/Hittite_updatedresults.csv",header=None,names=["Identical Matches","Hittite_Words","Linear A Word","Source"])
HittiteUpdatedResults_Source = df18.loc[:,"Source"] 
HittiteUpdatedResults_LAword = df18.loc[:,"Linear A Word"] 
HittiteUpdatedResults_word = df18.loc[:,"Hittite_Words"] 
HittiteUpdatedResults_matches = df18.loc[:,"Identical Matches"] 

df19 = pd.read_csv("Updated_results/Luwian_updatedresults.csv",header=None,names=["Identical Matches","Luwian_Words","Linear A Word","Source"])
LuwianUpdatedResults_matches = df19.loc[:,"Identical Matches"] 
LuwianUpdatedResults_word = df19.loc[:,"Luwian_Words"]
LuwianUpdatedResults_LAword = df19.loc[:,"Linear A Word"]  
LuwianUpdatedResults_Source = df19.loc[:,"Source"] 

df20 = df18 = pd.read_csv("Updated_results/Pre_Basque_updatedresults.csv",header=None,names=["Identical Matches","Pre_Basque_Words","Linear A Word","Source"])
Pre_BasqueUpdatedResults_matches = df20.loc[:,"Identical Matches"] 
Pre_BasqueUpdatedResults_word = df20.loc[:,"Pre_Basque_Words"]
Pre_BasqueUpdatedResults_LAword = df20.loc[:,"Linear A Word"]  
Pre_BasqueUpdatedResults_Source = df20.loc[:,"Source"] 

df21 = pd.read_csv("Updated_results/Proto_Basque_updatedresults.csv",header=None,names=["Identical Matches","Proto_Basque_Words","Linear A Word","Source"])
Proto_BasqueUpdatedResults_matches = df21.loc[:,"Identical Matches"] 
Proto_BasqueUpdatedResults_word = df21.loc[:,"Proto_Basque_Words"]
Proto_BasqueUpdatedResults_LAword = df21.loc[:,"Linear A Word"]  
Proto_BasqueUpdatedResults_Source = df21.loc[:,"Source"] 

df22 = pd.read_csv("Updated_results/Thracian_updatedresults.csv",header=None,names=["Identical Matches","Thracian_Words","Linear A Word","Source"])
ThracianUpdatedResults_matches = df22.loc[:,"Identical Matches"] 
ThracianUpdatedResults_word = df22.loc[:,"Thracian_Words"]
ThracianUpdatedResults_LAword = df22.loc[:,"Linear A Word"]  
ThracianUpdatedResults_Source = df22.loc[:,"Source"] 

df23 = pd.read_excel("Comparison_results/comparison()_results.xlsx",header=None, names=["Identical Matches", "Dictionary Word", "Linear A Word", "Frequency", "Percentage(%)"])
Analysis_1_matches = df23.loc[:,"Identical Matches"]
Analysis_1_dict_word = df23.loc[:,"Dictionary Word"]
Analysis_1_LA_word = df23.loc[:,"Linear A Word"]
Analysis_1_frequency = df23.loc[:,"Frequency"]
Analysis_1_percentage = df23.loc[:,"Percentage(%)"]

df24 = pd.read_csv("cal_percentage/percentage_results.csv",header=None,names=["Dictionary","Unique matches", "Total words","Percentage"])
Percentage_count = df24.loc[1:,"Percentage"]
Unique_matches = df24.loc[1:,"Unique matches"]
Total_words = df24.loc[1:,"Total words"]

df25 = pd.read_csv("Updated_results/Albanian_updatedresults.csv",header=None,names=["Identical Matches","Albanian_Words","Linear A Word","Source"])
AlbanianUpdatedResults_matches = df25.loc[:,"Identical Matches"]
AlbanianUpdatedResults_word = df25.loc[:,"Albanian_Words"]
AlbanianUpdatedResults_LAword = df25.loc[:,"Linear A Word"]
AlbanianUpdatedResults_Source = df25.loc[:,"Source"]

df26 = pd.read_csv("Updated_results/Egyptian_updatedresults.csv",header=None,names=["Identical Matches","Egyptian_Words","Linear A Word","Source"])
EgyptianUpdatedResults_matches = df26.loc[:,"Identical Matches"]
EgyptianUpdatedResults_word = df26.loc[:,"Egyptian_Words"]
EgyptianUpdatedResults_LAword = df26.loc[:,"Linear A Word"]
EgyptianUpdatedResults_Source = df26.loc[:,"Source"]

df27 = pd.read_csv("Updated_results/Proto_Celtic_updatedresults.csv",header=None,names=["Identical Matches","Proto_Celtic_Words","Linear A Word","Source"])
Proto_CelticUpdatedResults_matches = df27.loc[:,"Identical Matches"]
Proto_CelticUpdatedResults_word = df27.loc[:,"Proto_Celtic_Words"]
Proto_CelticUpdatedResults_LAword = df27.loc[:,"Linear A Word"]
Proto_CelticUpdatedResults_Source = df27.loc[:,"Source"]


Percentage_count = Percentage_count.values.tolist()
Unique_matches = Unique_matches.values.tolist()
Total_words = Total_words.values.tolist()

def convert_to_str(mylist):
    newlist=[]
    L = len(mylist)
    for i in range(L):
        newlist.append(str(mylist[i]))
    return newlist

def RemoveVowels(mylist):
    outputlist=[]
    for elem in mylist:
        newlist=list(elem)
        for elem1 in newlist:
            if elem1 == None:
                pass
            if elem1 == "a":
                newlist.remove("a")
            if elem1 == "e":
                newlist.remove("e")
            if elem1 == "i":
                newlist.remove("i")
            if elem1 == "o":
                newlist.remove("o")
            if elem1 == "u":
                newlist.remove("u")
        newstr="".join(newlist)
        outputlist.append(newstr)
    return outputlist

complied_list=[]
for i in range(len(LinearA)):
    complied_list.append([LinearA[i],LinearA_Without_Gaps[i],LinearA_source[i]])


def merge_3components_into_list(matches,complied_list):
    outputlist=[]
    for elem in matches:
        for j in range(len(complied_list)):
            if elem==complied_list[j][0]:
                outputlist.append(complied_list[j])
    return outputlist

def remove_duplicates(outputlist):
    outputlist1=[]
    for elem in outputlist:
        if elem not in outputlist1:
            outputlist1.append(elem)
    return outputlist1


def add_original_source_word_into_list(mylist,mylist2):
    for elem in mylist:
        for elem2 in mylist2:
            if elem[0] == elem2[0] and len(elem) < 4:
                elem.append(elem2[1])
            else:
                pass
    return mylist


alphabets = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
             'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

def numbered_to_freq(path: str) -> {}:
    num_to_freq = {}
    num_to_el = {}
    for entry in numbered_to_matched(path):
        numbered = entry[0]
        matched = entry[1]

        try:
            num_to_el[numbered] = num_to_el[numbered] + matched
        except KeyError:
            num_to_el.update({numbered: matched})

    for k, v in num_to_el.items():
        num_to_freq.update({k: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]})
        for char in set(v):
            num_to_freq[k][alphabets.index(char)] = v.count(char)

    return num_to_freq



# Helper method
def numbered_to_matched(path: str) -> []:
    fin_list = []
    with open(path, 'r') as f:
        lines = [l.strip() for l in f.readlines()]
        del lines[0]

        for line in lines:
            k, v = line.split(',')
            cremove = []
            for char in k:
                if char in alphabets:
                    cremove.append(char)
                    k = k.replace(char, '')

            numbers = [k[i:i + 3] for i in range(0, len(k), 3)]
            matched = []

            for char in v:
                if char in cremove:
                    v.replace(char, '')
                else:
                    matched.append(char)

            for i, j in zip(numbers, matched):
                fin_list.append([i, j])

    return fin_list

##frequency analysis of the matches results from specific dictionary
Anatolia_NumberedFreq_Analysis = numbered_to_freq("misc/Anatolia_numberedWords.csv")

Luwian_NumberedFreq_Analysis =  numbered_to_freq("misc/Luwian_numberedWords.csv")

Hittite_NumberedFreq_Analysis =  numbered_to_freq("misc/Hittite_numberedWords.csv")

Hamito_NumberedFreq_Analysis =  numbered_to_freq("misc/Hamito_numberedWords.csv")

Thracian_NumberedFreq_Analysis =  numbered_to_freq("misc/Thracian_numberedWords.csv")

Pre_Basque_NumberedFreq_Analysis =  numbered_to_freq("misc/Pre_Basque_numberedWords.csv")

Post_Basque_NumberedFreq_Analysis =  numbered_to_freq("misc/Post_Basque_numberedWords.csv")

Proto_Celtic_NumberedFreq_Analysis = numbered_to_freq("misc/Proto_Celtic_numberedWords.csv")

Albanian_NumberedFreq_Analysis = numbered_to_freq("misc/Albanian_numberedWords.csv")

AncientEgyptian_NumberedFreq_Analysis= numbered_to_freq("misc/AncientEgyptian_numberedWords.csv")

def convert_dict_to_list(D):
    outputlist=[]
    for elem in D:
        newlist=[]
        newlist=[elem]
        for i in D[elem]:
            newlist.append(i)
        outputlist.append(newlist)
    return outputlist

startlist = ['Triplets','a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm','n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']


Anatolia_NumberedFreq_Analysis_list = convert_dict_to_list(Anatolia_NumberedFreq_Analysis)
Anatolia_NumberedFreq_Analysis_list.insert(0,startlist)

Luwian_NumberedFreq_Analysis_list = convert_dict_to_list(Luwian_NumberedFreq_Analysis)
Luwian_NumberedFreq_Analysis_list.insert(0,startlist)

Hittite_NumberedFreq_Analysis_list =  convert_dict_to_list(Hittite_NumberedFreq_Analysis)
Hittite_NumberedFreq_Analysis_list.insert(0,startlist)

Hamito_NumberedFreq_Analysis_list = convert_dict_to_list(Hamito_NumberedFreq_Analysis)
Hamito_NumberedFreq_Analysis_list.insert(0,startlist)

Thracian_NumberedFreq_Analysis_list = convert_dict_to_list(Thracian_NumberedFreq_Analysis)
Thracian_NumberedFreq_Analysis_list.insert(0,startlist)

Pre_Basque_NumberedFreq_Analysis_list = convert_dict_to_list(Pre_Basque_NumberedFreq_Analysis)
Pre_Basque_NumberedFreq_Analysis_list.insert(0,startlist)

Post_Basque_NumberedFreq_Analysis_list = convert_dict_to_list(Post_Basque_NumberedFreq_Analysis)
Post_Basque_NumberedFreq_Analysis_list.insert(0,startlist)

Albanian_NumberedFreq_Analysis_list = convert_dict_to_list(Albanian_NumberedFreq_Analysis)
Albanian_NumberedFreq_Analysis_list.insert(0,startlist)

Proto_Celtic_NumberedFreq_Analysis_list = convert_dict_to_list(Proto_Celtic_NumberedFreq_Analysis)
Proto_Celtic_NumberedFreq_Analysis_list.insert(0,startlist)

AncientEgyptian_NumberedFreq_Analysis_list = convert_dict_to_list(AncientEgyptian_NumberedFreq_Analysis)
AncientEgyptian_NumberedFreq_Analysis_list.insert(0,startlist)

df_Anatolia = pd.DataFrame(Anatolia_NumberedFreq_Analysis_list[1:], columns =Anatolia_NumberedFreq_Analysis_list[0])

df_Luwian = pd.DataFrame(Luwian_NumberedFreq_Analysis_list[1:], columns = Luwian_NumberedFreq_Analysis_list[0])

df_Hittite = pd.DataFrame(Hittite_NumberedFreq_Analysis_list[1:], columns = Hittite_NumberedFreq_Analysis_list[0])

df_Pre_Basque = pd.DataFrame(Pre_Basque_NumberedFreq_Analysis_list[1:], columns = Pre_Basque_NumberedFreq_Analysis_list[0])

df_Post_Basque = pd.DataFrame(Post_Basque_NumberedFreq_Analysis_list[1:], columns = Post_Basque_NumberedFreq_Analysis_list[0])

df_Thracian = pd.DataFrame(Thracian_NumberedFreq_Analysis_list[1:], columns = Thracian_NumberedFreq_Analysis_list[0])

df_Hamito = pd.DataFrame(Hamito_NumberedFreq_Analysis_list[1:], columns = Hamito_NumberedFreq_Analysis_list[0])


class MainWindow(QMainWindow):
    def __init__(self,parent=None):
        super(MainWindow, self).__init__(parent)
        
        #Background Image
        self.setGeometry(50,50,00,600) #50,50,00,600
        self.setFixedSize(700,900)
        oImage = QImage("misc/background.jpg")
        sImage = oImage.scaled(QSize(700,900)) #700,900
        palette = QPalette()
        palette.setBrush(10,QBrush(sImage))
        self.setPalette(palette)
        
        self.startCoverPage()

    def startCoverPage(self):
        self.Window = CoverPage(self)
        self.setWindowTitle("Main Window")
        self.setCentralWidget(self.Window)
        self.Window.specificButton.clicked.connect(self.startMainMenu)
        self.Window.generalButton2.clicked.connect(self.startGeneralDecipherment2)
        #---------
        self.Window.generalButton3.clicked.connect(self.startGeneralDecipherment3)
        #---------
        self.Window.analysis_1_Button.clicked.connect(self.startanalysis_1)
        #---------
        self.show()

    def startMainMenu(self):
        
        self.MainMenu = MainMenu(self)
        self.setWindowTitle("Linear A decipherment Programme")
        self.setCentralWidget(self.MainMenu)
        self.MainMenu.HamitoDecipherment.clicked.connect(self.startHamitoDecipherMenu)
        self.MainMenu.LuwianDecipherment.clicked.connect(self.startLuwianDecipherMenu)
        self.MainMenu.AnatoliaDecipherment.clicked.connect(self.startAnatoliaDecipherMenu)
        self.MainMenu.HittiteDecipherment.clicked.connect(self.startHittiteDecipherMenu)
        self.MainMenu.ThracianDecipherment.clicked.connect(self.startThracianDecipherMenu)
        self.MainMenu.BasqueDecipherment.clicked.connect(self.startBasqueDecipherMenu)
        self.MainMenu.AlbanianDecipherment.clicked.connect(self.startAlbanianDecipherMenu)
        self.MainMenu.Proto_CelticDecipherment.clicked.connect(self.startProto_CelticDecipherMenu)
        self.MainMenu.AncientEgyptianDecipherment.clicked.connect(self.startAncientEgyptianDecipherMenu)
        self.MainMenu.backButton.clicked.connect(self.startCoverPage)
        
    def startGeneralDecipherment(self):
        self.GeneralDecipherment = GeneralDecipherment(self)
        self.setWindowTitle("General Decipherment")
        self.setCentralWidget(self.GeneralDecipherment)
        self.GeneralDecipherment.backButton.clicked.connect(self.startCoverPage)


    def startGeneralDecipherment2(self):
        self.GeneralDecipherment2 = GeneralDecipherment2(self)
        self.setWindowTitle("General Decipherment 2")
        self.setCentralWidget(self.GeneralDecipherment2)
        self.GeneralDecipherment2.backButton.clicked.connect(self.startCoverPage)
    
    def startGeneralDecipherment3(self):
        self.GeneralDecipherment3 = GeneralDecipherment3(self)
        self.setWindowTitle("LinAfontconv")
        self.setCentralWidget(self.GeneralDecipherment3)
        self.GeneralDecipherment3.backButton.clicked.connect(self.startCoverPage)

    def startanalysis_1(self):
        self.analysis_1 = analysis_1(self)
        self.setWindowTitle("Analysis - I")
        self.setCentralWidget(self.analysis_1)
        self.analysis_1.backButton.clicked.connect(self.startCoverPage)
    #-------------

    def startHamitoDecipherMenu(self):
        self.HamitoDecipherMenu = HamitoDecipherMenu(self)
        self.setCentralWidget(self.HamitoDecipherMenu)
        self.HamitoDecipherMenu.backButton.clicked.connect(self.startMainMenu)
        self.HamitoDecipherMenu.PercentageButton.clicked.connect(self.startHamitoPercentageAnalysis)

    def startHamitoPercentageAnalysis(self):
        self.HamitoPercentageAnalysis = HamitoPercentageAnalysis(self.HamitoDecipherMenu)
        self.setCentralWidget(self.HamitoPercentageAnalysis)
        self.HamitoPercentageAnalysis.backButton.clicked.connect(self.startMainMenu)
        
    def startLuwianDecipherMenu(self):
        self.LuwianDecipherMenu = LuwianDecipherMenu(self)
        self.setCentralWidget(self.LuwianDecipherMenu)
        self.LuwianDecipherMenu.backButton.clicked.connect(self.startMainMenu)
        self.LuwianDecipherMenu.PercentageButton.clicked.connect(self.startLuwianPercentageAnalysis)

    def startAlbanianDecipherMenu(self):
        self.AlbanianDecipherMenu = AlbanianDecipherMenu(self)
        self.setCentralWidget(self.AlbanianDecipherMenu)
        self.AlbanianDecipherMenu.backButton.clicked.connect(self.startMainMenu)
        self.AlbanianDecipherMenu.PercentageButton.clicked.connect(self.startAlbanianPercentageAnalysis)

    def startAlbanianPercentageAnalysis(self):
        self.AlbanianPercentageAnalysis = AlbanianPercentageAnalysis(self.AlbanianDecipherMenu)
        self.setCentralWidget(self.AlbanianPercentageAnalysis)
        self.AlbanianPercentageAnalysis.backButton.clicked.connect(self.startMainMenu)

    def startAncientEgyptianDecipherMenu(self):
        self.AncientEgyptianDecipherMenu = AncientEgyptianDecipherMenu(self)
        self.setCentralWidget(self.AncientEgyptianDecipherMenu)
        self.AncientEgyptianDecipherMenu.backButton.clicked.connect(self.startMainMenu)
        self.AncientEgyptianDecipherMenu.PercentageButton.clicked.connect(self.startAncientEgyptianPercentageAnalysis)

    def startAncientEgyptianPercentageAnalysis(self):
        self.AncientEgyptianPercentageAnalysis = AncientEgyptianPercentageAnalysis(self.AncientEgyptianDecipherMenu)
        self.setCentralWidget(self.AncientEgyptianPercentageAnalysis)
        self.AncientEgyptianPercentageAnalysis.backButton.clicked.connect(self.startMainMenu)

    def startProto_CelticDecipherMenu(self):
        self.Proto_CelticDecipherMenu = Proto_CelticDecipherMenu(self)
        self.setCentralWidget(self.Proto_CelticDecipherMenu)
        self.Proto_CelticDecipherMenu.backButton.clicked.connect(self.startMainMenu)
        self.Proto_CelticDecipherMenu.PercentageButton.clicked.connect(self.startProto_CelticPercentageAnalysis)

    def startProto_CelticPercentageAnalysis(self):
        self.Proto_CelticPercentageAnalysis = Proto_CelticPercentageAnalysis(self.Proto_CelticDecipherMenu)
        self.setCentralWidget(self.Proto_CelticPercentageAnalysis)
        self.Proto_CelticPercentageAnalysis.backButton.clicked.connect(self.startMainMenu)

    def startLuwianPercentageAnalysis(self):
        self.LuwianPercentageAnalysis = LuwianPercentageAnalysis(self.LuwianDecipherMenu)
        self.setCentralWidget(self.LuwianPercentageAnalysis)
        self.LuwianPercentageAnalysis.backButton.clicked.connect(self.startMainMenu)
        
    def startAnatoliaDecipherMenu(self):
        self.AnatoliaDecipherMenu = AnatoliaDecipherMenu(self)
        self.setCentralWidget(self.AnatoliaDecipherMenu)
        self.AnatoliaDecipherMenu.backButton.clicked.connect(self.startMainMenu)
        self.AnatoliaDecipherMenu.PercentageButton.clicked.connect(self.startAnatoliaPercentageAnalysis)

    def startAnatoliaPercentageAnalysis(self):
        self.AnatoliaPercentageAnalysis = AnatoliaPercentageAnalysis(self.AnatoliaDecipherMenu)
        self.setCentralWidget(self.AnatoliaPercentageAnalysis)
        self.AnatoliaPercentageAnalysis.backButton.clicked.connect(self.startMainMenu)

    def startHittiteDecipherMenu(self):
        self.HittiteDecipherMenu = HittiteDecipherMenu(self)
        self.setCentralWidget(self.HittiteDecipherMenu)
        self.HittiteDecipherMenu.backButton.clicked.connect(self.startMainMenu)
        self.HittiteDecipherMenu.PercentageButton.clicked.connect(self.startHittitePercentageAnalysis)


    def startHittitePercentageAnalysis(self):
        self.HittitePercentageAnalysis = HittitePercentageAnalysis(self.HittiteDecipherMenu)
        self.setCentralWidget(self.HittitePercentageAnalysis)
        self.HittitePercentageAnalysis.backButton.clicked.connect(self.startMainMenu)

    def startThracianDecipherMenu(self):
        self.ThracianDecipherMenu = ThracianDecipherMenu(self)
        self.setCentralWidget(self.ThracianDecipherMenu)
        self.ThracianDecipherMenu.backButton.clicked.connect(self.startMainMenu)
        self.ThracianDecipherMenu.PercentageButton.clicked.connect(self.startThracianPercentageAnalysis)

    def startThracianPercentageAnalysis(self):
        self.ThracianPercentageAnalysis = ThracianPercentageAnalysis(self.ThracianDecipherMenu)
        self.setCentralWidget(self.ThracianPercentageAnalysis)
        self.ThracianPercentageAnalysis.backButton.clicked.connect(self.startMainMenu)

    def startBasqueDecipherMenu(self):
        self.BasqueDecipherMenu = BasqueDecipherMenu(self)
        self.setCentralWidget(self.BasqueDecipherMenu)
        self.BasqueDecipherMenu.backButton.clicked.connect(self.startMainMenu)
        self.BasqueDecipherMenu.PercentageButton.clicked.connect(self.startBasquePercentageAnalysis)

    def startBasquePercentageAnalysis(self):
        self.BasquePercentageAnalysis = BasquePercentageAnalysis(self.BasqueDecipherMenu)
        self.setCentralWidget(self.BasquePercentageAnalysis)
        self.BasquePercentageAnalysis.backButton.clicked.connect(self.startMainMenu)


class CoverPage(QWidget):
    
    def __init__(self,parent):
        super(CoverPage,self).__init__(parent)

        self.specificButton = QPushButton('Specific Decipherment', self)
        self.specificButton.move(250,450) #250,450
        self.specificButton.resize(230, 60)
        self.specificButton.setFont(QFont('Times', 13))
        self.specificButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 18px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
               
        self.generalButton2 = QPushButton('General Decipherment', self)
        self.generalButton2.move(250,250) #250,250
        self.generalButton2.resize(230,60)
        self.generalButton2.setFont(QFont('Times',13))
        self.generalButton2.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 17px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.generalButton3 = QPushButton('LinAfontConv', self)
        self.generalButton3.move(250,350) #250,350
        self.generalButton3.resize(230,60)
        self.generalButton3.setFont(QFont('Times',13))
        self.generalButton3.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 17px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.analysis_1_Button = QPushButton('Analysis - I', self)
        self.analysis_1_Button.move(250,550) #250,550
        self.analysis_1_Button.resize(230,60)
        self.analysis_1_Button.setFont(QFont('Times',13))
        self.analysis_1_Button.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 17px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.show()


class GeneralDecipherment(QWidget):
    
    def __init__(self,parent):
        super(GeneralDecipherment,self).__init__(parent)
        
        self.verticalLayout = QVBoxLayout(self)
        
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setMinimumHeight(30)
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 18px;
                                          padding: 6px;
                                          background-color: rgb(245,170,125);
                                          }""")

        
        self.uploadButton = QPushButton(self)
        self.uploadButton.setMinimumHeight(30)
        self.uploadButton.setText('Upload Sheet')
        self.uploadButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 18px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.uploadButton.clicked.connect(self.openFileDialog)
        
        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.uploadButton)
        

        self.tableWidget1 = QTableWidget(self)
        self.tableWidget1.setColumnCount(4)
        self.tableWidget1.setHorizontalHeaderLabels(['Identical Matches', 'LinearA Word', 'Original_Word','Source'])
        self.tableWidget1.setRowCount(0)
        self.tableWidget1.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: inset;
                                          border-color: beige;
                                          }""")

        
        self.verticalLayout.addWidget(self.tableWidget1)
        self.verticalLayout.setAlignment(Qt.AlignTop)
        
        self.vowels = {'a', 'e', 'i', 'o', 'u'}
        self.show()

    
 
    def openFileDialog(self):
        self.tableWidget1.setRowCount(0)
        self.df_load = []
        self.df_load2=[]
        self.identical_matches = []
        self.templist=[]
        
        filename, _ = QFileDialog.getOpenFileName(self, 'Open CSV File', os.getcwd(), "csv (*.csv)")
        
        def rem_vowel(string): 
            vowels = ('a', 'e', 'i', 'o', 'u')  
            for x in string.lower(): 
                if x in vowels: 
                    string = string.replace(x, "") 
            return string

        
        if filename:
            loaded_data = pd.read_csv(filename)
            loaded_data = loaded_data.iloc[:, 0].values
  
            for item in loaded_data:
                temp_list = []
                for i in item:
                    if str(i) not in self.vowels:
                        temp_list.append(str(i))
                self.df_load.append(''.join(temp_list))
            
            for elem in self.df_load:
                self.df_load2.append([elem])
                
            
            for editedword in self.df_load2:
                for originalword in loaded_data:
                    if rem_vowel(originalword) == editedword[0] and len(editedword) != 2:
                        editedword.insert(0,originalword)                    
            
        
            self.updateGeneralDeciphermentTable()
                
        else:
            print('File Not Found or Not Supported.')
    
    
    def updateGeneralDeciphermentTable(self):
        for word in self.df_load2:
            for elem in complied_list:
                if (word[1]).lower() == elem[0] and len(word) !=4:
                    self.templist = [word[0],word[1],elem[1],elem[2]]
                    self.identical_matches.append(self.templist)
                    self.templist=[]
                    
        def remove_duplicates(outputlist):
            outputlist1=[]
            for elem in outputlist:
                if elem not in outputlist1:
                    outputlist1.append(elem)
            return outputlist1
        
        self.identical_matches = remove_duplicates(self.identical_matches)
        self.identical_matches.sort()
        

        self.tableWidget1.setRowCount(len(self.identical_matches))


        for i in range(len(self.identical_matches)):
            self.tableWidget1.setItem(i,0,QTableWidgetItem(str(self.identical_matches[i][1]))) # column 1 - Identical Matches
            self.tableWidget1.setItem(i,1,QTableWidgetItem(str(self.identical_matches[i][2]))) # column 2 - Linear A word
            self.tableWidget1.setItem(i,2,QTableWidgetItem(str(self.identical_matches[i][0]))) # column 0 - Original_Word
            self.tableWidget1.setItem(i,3,QTableWidgetItem(str(self.identical_matches[i][-1]))) # column 3 - Source
        
            
        df_upload = pd.DataFrame(self.identical_matches, columns=['Original_Word', 'Identical Matches', 'Linear A word','Source'])
        df_upload.to_csv('New_Matches.csv', sep=',')

#----------------
class GeneralDecipherment3(QWidget):
    def __init__(self,parent):
        super(GeneralDecipherment3,self).__init__(parent)
        self.verticalLayout = QVBoxLayout(self)
        self.horizontalLaout = QHBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setMinimumHeight(30)
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 18px;
                                          padding: 6px;
                                          background-color: rgb(245,170,125);
                                          }""")

        self.uploadButton = QPushButton(self)
        self.uploadButton.setMinimumHeight(30)
        self.uploadButton.setText('Upload Sheet')
        self.uploadButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 18px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.uploadButton.clicked.connect(self.openFileDialog_new_update)        

        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.uploadButton)

        self.tableWidget1 = QTableWidget(self)
        self.tableWidget1.setColumnCount(5)
        self.tableWidget1.setRowCount(0)
        self.tableWidget1.setFixedWidth(700)
        self.tableWidget1.setStyleSheet("""
                                         QWidget{
                                         border-radius: 30px;
                                         border-style: inset;
                                         border-color: beige;
                                         background-color: rgb(220,255,220);
                                         }""")

        self.horizontalLaout.addWidget(self.tableWidget1)
        self.horizontalLaout.setAlignment(Qt.AlignCenter)
        self.verticalLayout.addLayout(self.horizontalLaout)
        self.compliedlistLinAfontconv=[]
        self.verticalLayout.setAlignment(Qt.AlignTop)
        self.show()

    def openFileDialog_new_update(self):
        filename, _ = QFileDialog.getOpenFileName(self, "Select Excel file to import",os.getcwd(),"Excel (*.xls *.xlsx)")
        loaded_data = pd.read_excel(filename, usecols = "A:D")
        self.LinAcol1 = loaded_data.iloc[:, 0].values  # Identical Matches
        self.LinAcol2 = loaded_data.iloc[:, 1].values  # Linear A word
        self.LinAcol3 = loaded_data.iloc[:, 2].values  # Dictionary Word
        self.LinAcol4 = loaded_data.iloc[:, 3].values  # Source
        self.LinAcol5 = loaded_data.iloc[:, 1].values  # Font Conv
        for i in range(len(self.LinAcol1)):
            self.compliedlistLinAfontconv.append(
                [str(self.LinAcol1[i]), str(self.LinAcol2[i]), str(self.LinAcol3[i]), str(self.LinAcol4[i]),
                 str(self.LinAcol5[i])])
        self.tableWidget1.setRowCount(len(self.LinAcol1))
        for i in range(len(self.LinAcol1)):
            self.tableWidget1.setItem(i, 0, QTableWidgetItem(self.compliedlistLinAfontconv[i][0]))
            self.tableWidget1.setItem(i, 1, QTableWidgetItem(self.compliedlistLinAfontconv[i][1]))
            self.tableWidget1.setItem(i, 2, QTableWidgetItem(self.compliedlistLinAfontconv[i][2]))
            self.tableWidget1.setItem(i, 3, QTableWidgetItem(self.compliedlistLinAfontconv[i][3]))
            self.tableWidget1.setItem(i, 4, QTableWidgetItem(self.compliedlistLinAfontconv[i][4]))
            self.tableWidget1.item(i,4).setFont(QFont("Linear A Draft1", 15))

        self.horizontalLaout.addWidget(self.tableWidget1)
        self.show()

        if filename:
            print("File exist")
            csv_files = [filename]
            with open(filename, 'r') as read_obj:
                # pass the file object to reader() to get the reader object
                for file in csv_files:
                    csv_reader = openpyxl.load_workbook(file)
                    sheet = csv_reader.active
                    for src, dst in zip(sheet['B:B'], sheet['E:E']):
                        dst.value = src.value
                    for k in sheet.columns:
                        for cell in k:
                            if "E" in str(cell).split(".")[1].strip(">"):
                                cell.font = Font(name="Linear A Draft1")
                    sheet['E1'] = "Linear A fonts"
                    sheet['E1'].font = Font(name = "Calibri")
                    csv_reader.save(file)

        else:
            print('File Not Found or Not Supported.')


#------------
 
        
class GeneralDecipherment2(QWidget):    
    def __init__(self,parent):
        super(GeneralDecipherment2,self).__init__(parent)
        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setMinimumHeight(30)
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 18px;
                                          padding: 6px;
                                          background-color: rgb(245,170,125);
                                          }""")

        
        self.uploadButton = QPushButton(self)
        self.uploadButton.setMinimumHeight(30)
        self.uploadButton.setText('Upload Base Sheet')
        self.uploadButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 18px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.uploadButton.clicked.connect(self.openFileDialog1)

        self.uploadButton2 = QPushButton(self)
        self.uploadButton2.setMinimumHeight(30)
        self.uploadButton2.setText('Upload Second Sheet')
        self.uploadButton2.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 18px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.uploadButton2.clicked.connect(self.openFileDialog2)
        
        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.uploadButton)
        self.verticalLayout.addWidget(self.uploadButton2)

        self.tableWidget1 = QTableWidget(self)
        self.tableWidget1.setColumnCount(4)
        self.tableWidget1.setHorizontalHeaderLabels(['Identical Matches', 'LinearA Word', 'Original_Word','Source'])
        self.tableWidget1.setRowCount(0)
        self.tableWidget1.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: inset;
                                          border-color: beige;
                                          }""")


        self.verticalLayout.addWidget(self.tableWidget1)
        self.verticalLayout.setAlignment(Qt.AlignTop)
        
        
        self.vowels = {'a', 'e', 'i', 'o', 'u'}
        
        self.LinearAdata=[]
        self.LinearAGorilaCode=[]
        self.LinearANewFormat=[]        
        self.complied_3_list=[] #Gorila Code - Linear A New Format - Linear A data
        
        self.show()
        
    def openFileDialog1(self):
        filename, _ = QFileDialog.getOpenFileName(self, 'Open CSV File', os.getcwd(), "csv (*.csv)")
        if filename:
            loaded_data = pd.read_csv(filename)
            self.LinearAGorilaCode = loaded_data.iloc[:,0].values #Gorila Code
            self.LinearANewFormat = loaded_data.iloc[:,1].values #New format of LinearA words
            self.LinearAdata = loaded_data.iloc[:,2].values #Linear A words without vowels
            for i in range(len(self.LinearAdata)):
                self.complied_3_list.append([str(self.LinearAGorilaCode[i]),str(self.LinearANewFormat[i]),str(self.LinearAdata[i])])
        else:
            print('File Not Found or Not Supported.')
            
    def openFileDialog2(self):
        
        def rem_vowel(string):
            vowels = ('a','e','i','o','u')
            for x in string.lower():
                if x in vowels:
                    string = string.replace(x,'')
            return string
        
        self.identicalmatches2=[]
        self.templist=[]
        self.df_loadA=[]
        self.df_loadB=[] #originalword - editedword
        filename, _ = QFileDialog.getOpenFileName(self, 'Open CSV File', os.getcwd(), "csv (*.csv)")
        if filename:
            loaded_data = pd.read_csv(filename)
            comparedlist = loaded_data.iloc[:,0].values
            
            for item in comparedlist:
                temp_list=[]
                for i in item:
                    if str(i) not in self.vowels:
                        temp_list.append(str(i))
                self.df_loadA.append(''.join(temp_list)) #Remove all vowels in the word
            
            for elem in self.df_loadA:
                self.df_loadB.append([elem])
                    
            for editedword in self.df_loadB:
                for originalword in comparedlist:
                    if rem_vowel(originalword) == editedword[0] and len(editedword) != 2:
                        editedword.insert(0,originalword)
            
            self.updateGeneralDeciphermentTable2()
        else:
            print('File Not Found or Not Supported.')
            
    def updateGeneralDeciphermentTable2(self):
        for word in self.df_loadB:
            for elem in self.complied_3_list:
                if (word[1]).lower() == (elem[-1]).lower():
                    self.templist = [word[1],elem[1],word[0],elem[0]]
                    self.identicalmatches2.append(self.templist) #Match -New Format-Orignal Word - Gorila Code
                    self.templist=[]
                    
        def remove_duplicates(outputlist):
            outputlist1=[]
            for elem in outputlist:
                if elem not in outputlist1:
                    outputlist1.append(elem)
            return outputlist1
                    
        self.identicalmatches2 = remove_duplicates(self.identicalmatches2)
        self.identicalmatches2.sort()
        
        self.tableWidget1.setRowCount(len(self.identicalmatches2))
        for i in range(len(self.identicalmatches2)):
            self.tableWidget1.setItem(i,0,QTableWidgetItem(str(self.identicalmatches2[i][0]))) #Identical match
            self.tableWidget1.setItem(i,1,QTableWidgetItem(str(self.identicalmatches2[i][1]))) #Linear A word
            self.tableWidget1.setItem(i,2,QTableWidgetItem(str(self.identicalmatches2[i][2]))) #Original Word
            self.tableWidget1.setItem(i,3,QTableWidgetItem(str(self.identicalmatches2[i][3]))) #Source (Gorila-Code)
            
        df_upload = pd.DataFrame(self.identicalmatches2, columns = ['Identical match','Linear A word','Original_Word','Source'])
        df_upload.to_csv('New_matches2.csv',sep=',',index=False)   
#-------------

class analysis_1(QWidget):
    def __init__(self,parent):
        super(analysis_1,self).__init__(parent)
        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setMinimumHeight(30)
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 5px;
                                          border-color: beige;
                                          font: bold 18px;
                                          padding: 6px;
                                          background-color: rgb(245,170,125);
                                          }""")
        self.verticalLayout.addWidget(self.backButton)
        self.tableWidget3 = QTableWidget(self)
        self.tableWidget3.setRowCount(len(Analysis_1_percentage))
        self.tableWidget3.setColumnCount(5)
        for i in range(len(Analysis_1_percentage)):
            self.tableWidget3.setItem(i, 0, QTableWidgetItem(Analysis_1_matches[i])) # Identical matches
            self.tableWidget3.setItem(i, 1, QTableWidgetItem(Analysis_1_dict_word[i])) # Dictionary Word
            self.tableWidget3.setItem(i, 2, QTableWidgetItem(Analysis_1_LA_word[i])) # Linear A Word1
            self.tableWidget3.setItem(i, 3, QTableWidgetItem(Analysis_1_frequency[i])) # Frequency
            self.tableWidget3.setItem(i, 4, QTableWidgetItem(Analysis_1_percentage[i]))  # Percentage
        self.verticalLayout.addWidget(self.tableWidget3)
        self.show()
            
class HamitoDecipherMenu(QWidget):
    def __init__ (self,parent):
        super(HamitoDecipherMenu,self).__init__(parent)
        
        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")
        self.PercentageButton = QPushButton(self)
        self.PercentageButton.setText("Percentage Analysis")
        self.PercentageButton.setStyleSheet("""
                                                  QWidget{
                                                  border-radius: 30px;
                                                  border-style: outset;
                                                  border-width: 4px;
                                                  border-color: beige;
                                                  font: bold 15px;
                                                  padding: 6px;
                                                  background-color: rgb(165,170,125);
                                                  }""")
        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.PercentageButton)

        self.createHamitoTable()
        self.show()
        
        
    def createHamitoTable(self):
        self.tableWidget = QTableWidget(self)
        self.tableWidget.setRowCount(len(Matches))
        self.tableWidget.setColumnCount(4)
        for i in range(len(Matches)):
            self.tableWidget.setItem(i,0,QTableWidgetItem(Matches[i]))
            self.tableWidget.setItem(i,1,QTableWidgetItem(Actual_Row[i]))
            self.tableWidget.setItem(i,2,QTableWidgetItem(Original_Word[i]))
            self.tableWidget.setItem(i,3,QTableWidgetItem(Source[i]))
        self.verticalLayout.addWidget(self.tableWidget)
        
        self.tableWidget2 = QTableWidget(self)
        self.tableWidget2.setRowCount(len(Hamito_NumberedFreq_Analysis_list))
        self.tableWidget2.setColumnCount(27)
        for i in range(len(Hamito_NumberedFreq_Analysis_list)):
            self.tableWidget2.setItem(i,0,QTableWidgetItem(Hamito_NumberedFreq_Analysis_list[i][0]))
            self.tableWidget2.setItem(i,1,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][1])))
            self.tableWidget2.setItem(i,2,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][2])))
            self.tableWidget2.setItem(i,3,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][3])))
            self.tableWidget2.setItem(i,4,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][4])))
            self.tableWidget2.setItem(i,5,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][5])))
            self.tableWidget2.setItem(i,6,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][6])))
            self.tableWidget2.setItem(i,7,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][7])))
            self.tableWidget2.setItem(i,8,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][8])))
            self.tableWidget2.setItem(i,9,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][9])))
            self.tableWidget2.setItem(i,10,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][10])))
            self.tableWidget2.setItem(i,11,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][11])))
            self.tableWidget2.setItem(i,12,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][12])))
            self.tableWidget2.setItem(i,13,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][13])))
            self.tableWidget2.setItem(i,14,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][14])))
            self.tableWidget2.setItem(i,15,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][15])))
            self.tableWidget2.setItem(i,16,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][16])))
            self.tableWidget2.setItem(i,17,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][17])))
            self.tableWidget2.setItem(i,18,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][18])))
            self.tableWidget2.setItem(i,19,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][19])))
            self.tableWidget2.setItem(i,20,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][20])))
            self.tableWidget2.setItem(i,21,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][21])))
            self.tableWidget2.setItem(i,22,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][22])))
            self.tableWidget2.setItem(i,23,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][23])))
            self.tableWidget2.setItem(i,24,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][24])))
            self.tableWidget2.setItem(i,25,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][25])))
            self.tableWidget2.setItem(i,26,QTableWidgetItem(str(Hamito_NumberedFreq_Analysis_list[i][26])))
        self.verticalLayout.addWidget(self.tableWidget2)

class HamitoPercentageAnalysis(QWidget):
    def __init__(self,parent):
        super(HamitoPercentageAnalysis,self).__init__(parent)

        self.layout = QVBoxLayout()
        self.tableWidget = QTableWidget(self)
        self.tableWidget.setRowCount(2)
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setItem(0,0, QTableWidgetItem("Number of unique matches"))
        self.tableWidget.setItem(0,1, QTableWidgetItem("Total Number of Words"))
        self.tableWidget.setItem(0,2, QTableWidgetItem("Percentage of Matches"))
        self.tableWidget.setItem(1,0, QTableWidgetItem(str(Unique_matches[6])))
        self.tableWidget.setItem(1,1, QTableWidgetItem(str(Total_words[6])))
        self.tableWidget.setItem(1,2, QTableWidgetItem(str(Percentage_count[6]+"%")))
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")

        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.tableWidget.setStyleSheet("""
                                            QWidget{
                                            border-radius: 30px;
                                            border-style: inset;
                                            border-color: beige;
                                            background-color: rgb(220,255,220);
                                                 }""")

        self.layout.addWidget(self.backButton)
        self.layout.addWidget(self.tableWidget)

        self.setLayout(self.layout)

        self.show()
    
class LuwianDecipherMenu(QWidget):
    
    def __init__(self,parent):
        super(LuwianDecipherMenu,self).__init__(parent)
        
        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.nextButton = QPushButton(self)
        self.nextButton.setText("Next")
        self.nextButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.PercentageButton = QPushButton(self)
        self.PercentageButton.setText("Percentage Analysis")
        self.PercentageButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.nextButton)
        self.verticalLayout.addWidget(self.PercentageButton)
                
        self.createLuwianTable()
        self.show()
    
    def createLuwianTable(self):        
        self.tableWidget3 = QTableWidget(self)

        self.tableWidget3.setRowCount(len(LuwianUpdatedResults_LAword))
        self.tableWidget3.setColumnCount(4)
        for i in range(len(LuwianUpdatedResults_LAword)):
            self.tableWidget3.setItem(i,0,QTableWidgetItem(LuwianUpdatedResults_matches[i]))
            self.tableWidget3.setItem(i,1,QTableWidgetItem(LuwianUpdatedResults_word[i]))
            self.tableWidget3.setItem(i,2,QTableWidgetItem(LuwianUpdatedResults_LAword[i]))
            self.tableWidget3.setItem(i,3,QTableWidgetItem(LuwianUpdatedResults_Source[i]))
        self.verticalLayout.addWidget(self.tableWidget3)
        
        self.tableWidget4 = QTableWidget(self)
        self.tableWidget4.setRowCount(len(Luwian_NumberedFreq_Analysis_list))
        self.tableWidget4.setColumnCount(27)
        for i in range(len(Luwian_NumberedFreq_Analysis_list)):
            self.tableWidget4.setItem(i,0,QTableWidgetItem(Luwian_NumberedFreq_Analysis_list[i][0]))
            self.tableWidget4.setItem(i,1,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][1])))
            self.tableWidget4.setItem(i,2,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][2])))
            self.tableWidget4.setItem(i,3,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][3])))
            self.tableWidget4.setItem(i,4,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][4])))
            self.tableWidget4.setItem(i,5,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][5])))
            self.tableWidget4.setItem(i,6,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][6])))
            self.tableWidget4.setItem(i,7,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][7])))
            self.tableWidget4.setItem(i,8,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][8])))
            self.tableWidget4.setItem(i,9,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][9])))
            self.tableWidget4.setItem(i,10,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][10])))
            self.tableWidget4.setItem(i,11,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][11])))
            self.tableWidget4.setItem(i,12,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][12])))
            self.tableWidget4.setItem(i,13,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][13])))
            self.tableWidget4.setItem(i,14,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][14])))
            self.tableWidget4.setItem(i,15,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][15])))
            self.tableWidget4.setItem(i,16,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][16])))
            self.tableWidget4.setItem(i,17,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][17])))
            self.tableWidget4.setItem(i,18,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][18])))
            self.tableWidget4.setItem(i,19,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][19])))
            self.tableWidget4.setItem(i,20,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][20])))
            self.tableWidget4.setItem(i,21,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][21])))
            self.tableWidget4.setItem(i,22,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][22])))
            self.tableWidget4.setItem(i,23,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][23])))
            self.tableWidget4.setItem(i,24,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][24])))
            self.tableWidget4.setItem(i,25,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][25])))
            self.tableWidget4.setItem(i,26,QTableWidgetItem(str(Luwian_NumberedFreq_Analysis_list[i][26])))
        self.verticalLayout.addWidget(self.tableWidget4)

        
class LuwianPercentageAnalysis(QWidget):
    def __init__(self,parent):
        super(LuwianPercentageAnalysis,self).__init__(parent)

        self.layout = QVBoxLayout()
        self.tableWidget = QTableWidget(self)
        self.tableWidget.setRowCount(2)
        self.tableWidget.setColumnCount(3)
        self.tableWidget.setItem(0,0, QTableWidgetItem("Number of unique matches"))
        self.tableWidget.setItem(0,1, QTableWidgetItem("Total Number of Words"))
        self.tableWidget.setItem(0,2, QTableWidgetItem("Percentage of Matches"))
        self.tableWidget.setItem(1,0, QTableWidgetItem(str(Unique_matches[2])))
        self.tableWidget.setItem(1,1, QTableWidgetItem(str(Total_words[2])))
        self.tableWidget.setItem(1,2, QTableWidgetItem(str(Percentage_count[2]+"%")))
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")

        self.tableWidget.setStyleSheet("""
                                            QWidget{
                                            border-radius: 30px;
                                            border-style: inset;
                                            border-color: beige;
                                            background-color: rgb(220,255,220);
                                                 }""")
        
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")

        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.layout.addWidget(self.backButton)
        self.layout.addWidget(self.tableWidget)

        self.setLayout(self.layout)

        self.show()


class AnatoliaDecipherMenu(QWidget):
    
    def __init__(self,parent):
        super(AnatoliaDecipherMenu,self).__init__(parent)
        
        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.nextButton = QPushButton(self)
        self.nextButton.setText("Next")
        self.nextButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
        self.PercentageButton = QPushButton(self)
        self.PercentageButton.setText("Percentage Analysis")
        self.PercentageButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
        
        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.nextButton)
        self.verticalLayout.addWidget(self.PercentageButton)

        self.createAnatoliaTable()
        self.show()
    
    def createAnatoliaTable(self):
        self.tableWidget3 = QTableWidget(self)
        self.tableWidget3.setRowCount(len(AnatoliaUpdatedResults_LAword))
        self.tableWidget3.setColumnCount(4)
        for i in range(len(AnatoliaUpdatedResults_LAword)):
            self.tableWidget3.setItem(i,0,QTableWidgetItem(AnatoliaUpdatedResults_matches[i]))
            self.tableWidget3.setItem(i,1,QTableWidgetItem(AnatoliaUpdatedResults_word[i]))
            self.tableWidget3.setItem(i,2,QTableWidgetItem(AnatoliaUpdatedResults_LAword[i]))
            self.tableWidget3.setItem(i,3,QTableWidgetItem(AnatoliaUpdatedResults_Source[i]))
        self.verticalLayout.addWidget(self.tableWidget3)
 
        
        self.tableWidget4 = QTableWidget(self)
        self.tableWidget4.setRowCount(len(Anatolia_NumberedFreq_Analysis_list))
        self.tableWidget4.setColumnCount(27)
        for i in range(len(Anatolia_NumberedFreq_Analysis_list)):
            self.tableWidget4.setItem(i,0,QTableWidgetItem(Anatolia_NumberedFreq_Analysis_list[i][0]))
            self.tableWidget4.setItem(i,1,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][1])))
            self.tableWidget4.setItem(i,2,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][2])))
            self.tableWidget4.setItem(i,3,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][3])))
            self.tableWidget4.setItem(i,4,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][4])))
            self.tableWidget4.setItem(i,5,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][5])))
            self.tableWidget4.setItem(i,6,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][6])))
            self.tableWidget4.setItem(i,7,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][7])))
            self.tableWidget4.setItem(i,8,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][8])))
            self.tableWidget4.setItem(i,9,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][9])))
            self.tableWidget4.setItem(i,10,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][10])))
            self.tableWidget4.setItem(i,11,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][11])))
            self.tableWidget4.setItem(i,12,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][12])))
            self.tableWidget4.setItem(i,13,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][13])))
            self.tableWidget4.setItem(i,14,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][14])))
            self.tableWidget4.setItem(i,15,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][15])))
            self.tableWidget4.setItem(i,16,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][16])))
            self.tableWidget4.setItem(i,17,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][17])))
            self.tableWidget4.setItem(i,18,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][18])))
            self.tableWidget4.setItem(i,19,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][19])))
            self.tableWidget4.setItem(i,20,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][20])))
            self.tableWidget4.setItem(i,21,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][21])))
            self.tableWidget4.setItem(i,22,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][22])))
            self.tableWidget4.setItem(i,23,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][23])))
            self.tableWidget4.setItem(i,24,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][24])))
            self.tableWidget4.setItem(i,25,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][25])))
            self.tableWidget4.setItem(i,26,QTableWidgetItem(str(Anatolia_NumberedFreq_Analysis_list[i][26])))
        self.verticalLayout.addWidget(self.tableWidget4)

class AnatoliaPercentageAnalysis(QWidget):
    def __init__(self,parent):
        super(AnatoliaPercentageAnalysis,self).__init__(parent)

        self.layout = QVBoxLayout()
        self.label1 = QLabel("Number of unique matches: " + str(Unique_matches[0]))
        self.label2 = QLabel("Total Number of Words: " + str(Total_words[0]))
        self.label3 = QLabel("Percentage of Matches: "+ str(Percentage_count[0]) + "%")
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")

        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")
        self.layout.addWidget(self.backButton)
        self.layout.addWidget(self.label1)
        self.layout.addWidget(self.label2)
        self.layout.addWidget(self.label3)


        self.setLayout(self.layout)

        self.show()

class HittiteDecipherMenu(QWidget):
    
    def __init__(self,parent):
        super(HittiteDecipherMenu,self).__init__(parent)
        
        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.nextButton = QPushButton(self)
        self.nextButton.setText("Next")
        self.nextButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.PercentageButton = QPushButton(self)
        self.PercentageButton.setText("Percentage Analysis")
        self.PercentageButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        
        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.nextButton)
        self.verticalLayout.addWidget(self.PercentageButton)
                
        self.createHittiteTable()
        self.show()
    
    def createHittiteTable(self):
        self.tableWidget3 = QTableWidget(self)
        self.tableWidget3.setRowCount(len(HittiteUpdatedResults_LAword))
        self.tableWidget3.setColumnCount(4)
        for i in range(len(HittiteUpdatedResults_LAword)):
            self.tableWidget3.setItem(i,0,QTableWidgetItem(HittiteUpdatedResults_matches[i]))
            self.tableWidget3.setItem(i,1,QTableWidgetItem(HittiteUpdatedResults_word[i]))
            self.tableWidget3.setItem(i,2,QTableWidgetItem(HittiteUpdatedResults_LAword[i]))
            self.tableWidget3.setItem(i,3,QTableWidgetItem(HittiteUpdatedResults_Source[i]))
        self.verticalLayout.addWidget(self.tableWidget3)

        
        self.tableWidget4 = QTableWidget(self)
        self.tableWidget4.setRowCount(len(Hittite_NumberedFreq_Analysis_list))
        self.tableWidget4.setColumnCount(27)
        for i in range(len(Hittite_NumberedFreq_Analysis_list)):
            self.tableWidget4.setItem(i,0,QTableWidgetItem(Hittite_NumberedFreq_Analysis_list[i][0]))
            self.tableWidget4.setItem(i,1,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][1])))
            self.tableWidget4.setItem(i,2,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][2])))
            self.tableWidget4.setItem(i,3,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][3])))
            self.tableWidget4.setItem(i,4,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][4])))
            self.tableWidget4.setItem(i,5,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][5])))
            self.tableWidget4.setItem(i,6,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][6])))
            self.tableWidget4.setItem(i,7,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][7])))
            self.tableWidget4.setItem(i,8,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][8])))
            self.tableWidget4.setItem(i,9,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][9])))
            self.tableWidget4.setItem(i,10,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][10])))
            self.tableWidget4.setItem(i,11,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][11])))
            self.tableWidget4.setItem(i,12,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][12])))
            self.tableWidget4.setItem(i,13,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][13])))
            self.tableWidget4.setItem(i,14,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][14])))
            self.tableWidget4.setItem(i,15,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][15])))
            self.tableWidget4.setItem(i,16,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][16])))
            self.tableWidget4.setItem(i,17,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][17])))
            self.tableWidget4.setItem(i,18,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][18])))
            self.tableWidget4.setItem(i,19,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][19])))
            self.tableWidget4.setItem(i,20,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][20])))
            self.tableWidget4.setItem(i,21,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][21])))
            self.tableWidget4.setItem(i,22,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][22])))
            self.tableWidget4.setItem(i,23,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][23])))
            self.tableWidget4.setItem(i,24,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][24])))
            self.tableWidget4.setItem(i,25,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][25])))
            self.tableWidget4.setItem(i,26,QTableWidgetItem(str(Hittite_NumberedFreq_Analysis_list[i][26])))
        self.verticalLayout.addWidget(self.tableWidget4)

class HittitePercentageAnalysis(QWidget):
    def __init__(self, parent):
        super(HittitePercentageAnalysis, self).__init__(parent)

        self.layout = QVBoxLayout()
        self.label1 = QLabel("Number of unique matches: " + str(Unique_matches[1]))
        self.label2 = QLabel("Total Number of Words: " + str(Total_words[1]))
        self.label3 = QLabel("Percentage of Matches: " + str(Percentage_count[1]) + "%")
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")

        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")
        self.layout.addWidget(self.backButton)
        self.layout.addWidget(self.label1)
        self.layout.addWidget(self.label2)
        self.layout.addWidget(self.label3)

        self.setLayout(self.layout)

        self.show()


class ThracianDecipherMenu(QWidget):
    
    def __init__(self,parent):
        super(ThracianDecipherMenu,self).__init__(parent)
        
        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.nextButton = QPushButton(self)
        self.nextButton.setText("Next")
        self.nextButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
        self.PercentageButton = QPushButton(self)
        self.PercentageButton.setText("Percentage Analysis")
        self.PercentageButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.nextButton)
        self.verticalLayout.addWidget(self.PercentageButton)
                
        self.createThracianTable()
        self.show()
    
    def createThracianTable(self):
        self.tableWidget3 = QTableWidget(self)
        self.tableWidget3.setRowCount(len(ThracianUpdatedResults_word))
        self.tableWidget3.setColumnCount(4)
        for i in range(len(ThracianUpdatedResults_word)):
            self.tableWidget3.setItem(i,0,QTableWidgetItem(str(ThracianUpdatedResults_matches[i])))
            self.tableWidget3.setItem(i,1,QTableWidgetItem(str(ThracianUpdatedResults_word[i])))
            self.tableWidget3.setItem(i,2,QTableWidgetItem(str(ThracianUpdatedResults_LAword[i])))
            self.tableWidget3.setItem(i,3,QTableWidgetItem(str(ThracianUpdatedResults_Source[i])))
        self.verticalLayout.addWidget(self.tableWidget3)
        
        
        self.tableWidget4 = QTableWidget(self)
        self.tableWidget4.setRowCount(len(Thracian_NumberedFreq_Analysis_list))
        self.tableWidget4.setColumnCount(27)
        for i in range(len(Thracian_NumberedFreq_Analysis_list)):
            self.tableWidget4.setItem(i,0,QTableWidgetItem(Thracian_NumberedFreq_Analysis_list[i][0]))
            self.tableWidget4.setItem(i,1,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][1])))
            self.tableWidget4.setItem(i,2,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][2])))
            self.tableWidget4.setItem(i,3,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][3])))
            self.tableWidget4.setItem(i,4,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][4])))
            self.tableWidget4.setItem(i,5,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][5])))
            self.tableWidget4.setItem(i,6,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][6])))
            self.tableWidget4.setItem(i,7,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][7])))
            self.tableWidget4.setItem(i,8,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][8])))
            self.tableWidget4.setItem(i,9,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][9])))
            self.tableWidget4.setItem(i,10,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][10])))
            self.tableWidget4.setItem(i,11,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][11])))
            self.tableWidget4.setItem(i,12,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][12])))
            self.tableWidget4.setItem(i,13,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][13])))
            self.tableWidget4.setItem(i,14,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][14])))
            self.tableWidget4.setItem(i,15,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][15])))
            self.tableWidget4.setItem(i,16,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][16])))
            self.tableWidget4.setItem(i,17,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][17])))
            self.tableWidget4.setItem(i,18,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][18])))
            self.tableWidget4.setItem(i,19,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][19])))
            self.tableWidget4.setItem(i,20,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][20])))
            self.tableWidget4.setItem(i,21,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][21])))
            self.tableWidget4.setItem(i,22,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][22])))
            self.tableWidget4.setItem(i,23,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][23])))
            self.tableWidget4.setItem(i,24,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][24])))
            self.tableWidget4.setItem(i,25,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][25])))
            self.tableWidget4.setItem(i,26,QTableWidgetItem(str(Thracian_NumberedFreq_Analysis_list[i][26])))
        self.verticalLayout.addWidget(self.tableWidget4)

class ThracianPercentageAnalysis(QWidget):
    def __init__(self, parent):
        super(ThracianPercentageAnalysis, self).__init__(parent)

        self.layout = QVBoxLayout()
        self.label1 = QLabel("Number of unique matches: " + str(Unique_matches[5]))
        self.label2 = QLabel("Total Number of Words: " + str(Total_words[5]))
        self.label3 = QLabel("Percentage of Matches: " + str(Percentage_count[5]) + "%")
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")

        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")
        self.layout.addWidget(self.backButton)
        self.layout.addWidget(self.label1)
        self.layout.addWidget(self.label2)
        self.layout.addWidget(self.label3)

        self.setLayout(self.layout)

        self.show()


class AlbanianDecipherMenu(QWidget):

    def __init__(self, parent):
        super(AlbanianDecipherMenu, self).__init__(parent)

        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.nextButton = QPushButton(self)
        self.nextButton.setText("Next")
        self.nextButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
        self.PercentageButton = QPushButton(self)
        self.PercentageButton.setText("Percentage Analysis")
        self.PercentageButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.nextButton)
        self.verticalLayout.addWidget(self.PercentageButton)

        self.createAlbanianTable()
        self.show()

    def createAlbanianTable(self):
        self.tableWidget3 = QTableWidget(self)
        self.tableWidget3.setRowCount(len(AlbanianUpdatedResults_word))
        self.tableWidget3.setColumnCount(4)
        for i in range(len(AlbanianUpdatedResults_word)):
            self.tableWidget3.setItem(i, 0, QTableWidgetItem(str(AlbanianUpdatedResults_matches[i])))
            self.tableWidget3.setItem(i, 1, QTableWidgetItem(str(AlbanianUpdatedResults_word[i])))
            self.tableWidget3.setItem(i, 2, QTableWidgetItem(str(AlbanianUpdatedResults_LAword[i])))
            self.tableWidget3.setItem(i, 3, QTableWidgetItem(str(AlbanianUpdatedResults_Source[i])))


        self.tableWidget2 = QTableWidget(self)
        self.tableWidget2.setRowCount(len(Albanian_NumberedFreq_Analysis_list))
        self.tableWidget2.setColumnCount(27)
        for i in range(len(Albanian_NumberedFreq_Analysis_list)):
            self.tableWidget2.setItem(i, 0, QTableWidgetItem(Albanian_NumberedFreq_Analysis_list[i][0]))
            self.tableWidget2.setItem(i, 1, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][1])))
            self.tableWidget2.setItem(i, 2, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][2])))
            self.tableWidget2.setItem(i, 3, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][3])))
            self.tableWidget2.setItem(i, 4, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][4])))
            self.tableWidget2.setItem(i, 5, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][5])))
            self.tableWidget2.setItem(i, 6, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][6])))
            self.tableWidget2.setItem(i, 7, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][7])))
            self.tableWidget2.setItem(i, 8, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][8])))
            self.tableWidget2.setItem(i, 9, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][9])))
            self.tableWidget2.setItem(i, 10, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][10])))
            self.tableWidget2.setItem(i, 11, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][11])))
            self.tableWidget2.setItem(i, 12, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][12])))
            self.tableWidget2.setItem(i, 13, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][13])))
            self.tableWidget2.setItem(i, 14, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][14])))
            self.tableWidget2.setItem(i, 15, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][15])))
            self.tableWidget2.setItem(i, 16, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][16])))
            self.tableWidget2.setItem(i, 17, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][17])))
            self.tableWidget2.setItem(i, 18, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][18])))
            self.tableWidget2.setItem(i, 19, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][19])))
            self.tableWidget2.setItem(i, 20, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][20])))
            self.tableWidget2.setItem(i, 21, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][21])))
            self.tableWidget2.setItem(i, 22, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][22])))
            self.tableWidget2.setItem(i, 23, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][23])))
            self.tableWidget2.setItem(i, 24, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][24])))
            self.tableWidget2.setItem(i, 25, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][25])))
            self.tableWidget2.setItem(i, 26, QTableWidgetItem(str(Albanian_NumberedFreq_Analysis_list[i][26])))
        self.verticalLayout.addWidget(self.tableWidget3)
        self.verticalLayout.addWidget(self.tableWidget2)

class AlbanianPercentageAnalysis(QWidget):
    def __init__(self,parent):
        super(AlbanianPercentageAnalysis,self).__init__(parent)

        self.layout = QVBoxLayout()
        self.label1 = QLabel("Number of unique matches: " + str(Unique_matches[7]))
        self.label2 = QLabel("Total Number of Words: " + str(Total_words[7]))
        self.label3 = QLabel("Percentage of Matches: "+ str(Percentage_count[7]) + "%")
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")

        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")
        self.layout.addWidget(self.backButton)
        self.layout.addWidget(self.label1)
        self.layout.addWidget(self.label2)
        self.layout.addWidget(self.label3)


        self.setLayout(self.layout)

        self.show()

class AncientEgyptianDecipherMenu(QWidget):

    def __init__(self, parent):
        super(AncientEgyptianDecipherMenu, self).__init__(parent)

        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.nextButton = QPushButton(self)
        self.nextButton.setText("Next")
        self.nextButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
        self.PercentageButton = QPushButton(self)
        self.PercentageButton.setText("Percentage Analysis")
        self.PercentageButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.nextButton)
        self.verticalLayout.addWidget(self.PercentageButton)

        self.createAncientEgyptianTable()
        self.show()

    def createAncientEgyptianTable(self):
        self.tableWidget3 = QTableWidget(self)
        self.tableWidget3.setRowCount(len(EgyptianUpdatedResults_word))
        self.tableWidget3.setColumnCount(4)
        for i in range(len(EgyptianUpdatedResults_word)):
            self.tableWidget3.setItem(i, 0, QTableWidgetItem(str(EgyptianUpdatedResults_matches[i])))
            self.tableWidget3.setItem(i, 1, QTableWidgetItem(str(EgyptianUpdatedResults_word[i])))
            self.tableWidget3.setItem(i, 2, QTableWidgetItem(str(EgyptianUpdatedResults_LAword[i])))
            self.tableWidget3.setItem(i, 3, QTableWidgetItem(str(EgyptianUpdatedResults_Source[i])))
        self.verticalLayout.addWidget(self.tableWidget3)

        self.tableWidget2 = QTableWidget(self)
        self.tableWidget2.setRowCount(len(AncientEgyptian_NumberedFreq_Analysis_list))
        self.tableWidget2.setColumnCount(27)
        for i in range(len(AncientEgyptian_NumberedFreq_Analysis_list)):
            self.tableWidget2.setItem(i, 0, QTableWidgetItem(AncientEgyptian_NumberedFreq_Analysis_list[i][0]))
            self.tableWidget2.setItem(i, 1, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][1])))
            self.tableWidget2.setItem(i, 2, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][2])))
            self.tableWidget2.setItem(i, 3, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][3])))
            self.tableWidget2.setItem(i, 4, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][4])))
            self.tableWidget2.setItem(i, 5, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][5])))
            self.tableWidget2.setItem(i, 6, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][6])))
            self.tableWidget2.setItem(i, 7, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][7])))
            self.tableWidget2.setItem(i, 8, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][8])))
            self.tableWidget2.setItem(i, 9, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][9])))
            self.tableWidget2.setItem(i, 10, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][10])))
            self.tableWidget2.setItem(i, 11, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][11])))
            self.tableWidget2.setItem(i, 12, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][12])))
            self.tableWidget2.setItem(i, 13, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][13])))
            self.tableWidget2.setItem(i, 14, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][14])))
            self.tableWidget2.setItem(i, 15, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][15])))
            self.tableWidget2.setItem(i, 16, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][16])))
            self.tableWidget2.setItem(i, 17, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][17])))
            self.tableWidget2.setItem(i, 18, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][18])))
            self.tableWidget2.setItem(i, 19, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][19])))
            self.tableWidget2.setItem(i, 20, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][20])))
            self.tableWidget2.setItem(i, 21, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][21])))
            self.tableWidget2.setItem(i, 22, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][22])))
            self.tableWidget2.setItem(i, 23, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][23])))
            self.tableWidget2.setItem(i, 24, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][24])))
            self.tableWidget2.setItem(i, 25, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][25])))
            self.tableWidget2.setItem(i, 26, QTableWidgetItem(str(AncientEgyptian_NumberedFreq_Analysis_list[i][26])))
        self.verticalLayout.addWidget(self.tableWidget3)
        self.verticalLayout.addWidget(self.tableWidget2)

class AncientEgyptianPercentageAnalysis(QWidget):
    def __init__(self,parent):
        super(AncientEgyptianPercentageAnalysis,self).__init__(parent)

        self.layout = QVBoxLayout()
        self.label1 = QLabel("Number of unique matches: " + str(Unique_matches[8]))
        self.label2 = QLabel("Total Number of Words: " + str(Total_words[8]))
        self.label3 = QLabel("Percentage of Matches: "+ str(Percentage_count[8]) + "%")
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")

        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")
        self.layout.addWidget(self.backButton)
        self.layout.addWidget(self.label1)
        self.layout.addWidget(self.label2)
        self.layout.addWidget(self.label3)


        self.setLayout(self.layout)

        self.show()


class Proto_CelticDecipherMenu(QWidget):

    def __init__(self, parent):
        super(Proto_CelticDecipherMenu, self).__init__(parent)

        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.nextButton = QPushButton(self)
        self.nextButton.setText("Next")
        self.nextButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
        self.PercentageButton = QPushButton(self)
        self.PercentageButton.setText("Percentage Analysis")
        self.PercentageButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.nextButton)
        self.verticalLayout.addWidget(self.PercentageButton)

        self.createProto_CelticTable()
        self.show()

    def createProto_CelticTable(self):
        self.tableWidget3 = QTableWidget(self)
        self.tableWidget3.setRowCount(len(Proto_CelticUpdatedResults_word))
        self.tableWidget3.setColumnCount(4)
        for i in range(len(Proto_CelticUpdatedResults_word)):
            self.tableWidget3.setItem(i, 0, QTableWidgetItem(str(Proto_CelticUpdatedResults_matches[i])))
            self.tableWidget3.setItem(i, 1, QTableWidgetItem(str(Proto_CelticUpdatedResults_word[i])))
            self.tableWidget3.setItem(i, 2, QTableWidgetItem(str(Proto_CelticUpdatedResults_LAword[i])))
            self.tableWidget3.setItem(i, 3, QTableWidgetItem(str(Proto_CelticUpdatedResults_Source[i])))
        self.verticalLayout.addWidget(self.tableWidget3)

        self.tableWidget2 = QTableWidget(self)
        self.tableWidget2.setRowCount(len(Proto_Celtic_NumberedFreq_Analysis_list))
        self.tableWidget2.setColumnCount(27)
        for i in range(len(Proto_Celtic_NumberedFreq_Analysis_list)):
            self.tableWidget2.setItem(i, 0, QTableWidgetItem(Proto_Celtic_NumberedFreq_Analysis_list[i][0]))
            self.tableWidget2.setItem(i, 1, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][1])))
            self.tableWidget2.setItem(i, 2, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][2])))
            self.tableWidget2.setItem(i, 3, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][3])))
            self.tableWidget2.setItem(i, 4, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][4])))
            self.tableWidget2.setItem(i, 5, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][5])))
            self.tableWidget2.setItem(i, 6, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][6])))
            self.tableWidget2.setItem(i, 7, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][7])))
            self.tableWidget2.setItem(i, 8, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][8])))
            self.tableWidget2.setItem(i, 9, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][9])))
            self.tableWidget2.setItem(i, 10, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][10])))
            self.tableWidget2.setItem(i, 11, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][11])))
            self.tableWidget2.setItem(i, 12, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][12])))
            self.tableWidget2.setItem(i, 13, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][13])))
            self.tableWidget2.setItem(i, 14, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][14])))
            self.tableWidget2.setItem(i, 15, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][15])))
            self.tableWidget2.setItem(i, 16, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][16])))
            self.tableWidget2.setItem(i, 17, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][17])))
            self.tableWidget2.setItem(i, 18, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][18])))
            self.tableWidget2.setItem(i, 19, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][19])))
            self.tableWidget2.setItem(i, 20, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][20])))
            self.tableWidget2.setItem(i, 21, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][21])))
            self.tableWidget2.setItem(i, 22, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][22])))
            self.tableWidget2.setItem(i, 23, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][23])))
            self.tableWidget2.setItem(i, 24, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][24])))
            self.tableWidget2.setItem(i, 25, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][25])))
            self.tableWidget2.setItem(i, 26, QTableWidgetItem(str(Proto_Celtic_NumberedFreq_Analysis_list[i][26])))
        self.verticalLayout.addWidget(self.tableWidget3)
        self.verticalLayout.addWidget(self.tableWidget2)

class Proto_CelticPercentageAnalysis(QWidget):
    def __init__(self,parent):
        super(Proto_CelticPercentageAnalysis,self).__init__(parent)

        self.layout = QVBoxLayout()
        self.label1 = QLabel("Number of unique matches: " + str(Unique_matches[9]))
        self.label2 = QLabel("Total Number of Words: " + str(Total_words[9]))
        self.label3 = QLabel("Percentage of Matches: "+ str(Percentage_count[9]) + "%")
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")

        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")
        self.layout.addWidget(self.backButton)
        self.layout.addWidget(self.label1)
        self.layout.addWidget(self.label2)
        self.layout.addWidget(self.label3)


        self.setLayout(self.layout)

        self.show()


class BasqueDecipherMenu(QWidget):
    
    def __init__(self,parent):
        super(BasqueDecipherMenu,self).__init__(parent)
        
        self.verticalLayout = QVBoxLayout(self)
        self.backButton = QPushButton(self)
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.backButton.setText("Back")
        self.nextButton = QPushButton(self)
        self.nextButton.setText("Next")
        self.nextButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
        self.PercentageButton = QPushButton(self)
        self.PercentageButton.setText("Percentage Analysis")
        self.PercentageButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
        
        self.verticalLayout.addWidget(self.backButton)
        self.verticalLayout.addWidget(self.nextButton)
        self.verticalLayout.addWidget(self.PercentageButton)

        self.createBasqueTable()
        self.show()
    
    def createBasqueTable(self):
        self.tableWidget3 = QTableWidget(self)
        self.tableWidget3.setRowCount(len(Pre_BasqueUpdatedResults_LAword))
        self.tableWidget3.setColumnCount(4)
        for i in range(len(Pre_BasqueUpdatedResults_LAword)):
            self.tableWidget3.setItem(i,0,QTableWidgetItem(str(Pre_BasqueUpdatedResults_matches[i])))
            self.tableWidget3.setItem(i,1,QTableWidgetItem(str(Pre_BasqueUpdatedResults_word[i])))
            self.tableWidget3.setItem(i,2,QTableWidgetItem(str(Pre_BasqueUpdatedResults_LAword[i])))
            self.tableWidget3.setItem(i,3,QTableWidgetItem(str(Pre_BasqueUpdatedResults_Source[i])))
        self.verticalLayout.addWidget(self.tableWidget3)
        
        self.tableWidget4 = QTableWidget(self)
        self.tableWidget4.setRowCount(len(Pre_Basque_NumberedFreq_Analysis_list))
        self.tableWidget4.setColumnCount(27)
        for i in range(len(Pre_Basque_NumberedFreq_Analysis_list)):
            self.tableWidget4.setItem(i,0,QTableWidgetItem(Pre_Basque_NumberedFreq_Analysis_list[i][0]))
            self.tableWidget4.setItem(i,1,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][1])))
            self.tableWidget4.setItem(i,2,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][2])))
            self.tableWidget4.setItem(i,3,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][3])))
            self.tableWidget4.setItem(i,4,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][4])))
            self.tableWidget4.setItem(i,5,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][5])))
            self.tableWidget4.setItem(i,6,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][6])))
            self.tableWidget4.setItem(i,7,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][7])))
            self.tableWidget4.setItem(i,8,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][8])))
            self.tableWidget4.setItem(i,9,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][9])))
            self.tableWidget4.setItem(i,10,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][10])))
            self.tableWidget4.setItem(i,11,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][11])))
            self.tableWidget4.setItem(i,12,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][12])))
            self.tableWidget4.setItem(i,13,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][13])))
            self.tableWidget4.setItem(i,14,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][14])))
            self.tableWidget4.setItem(i,15,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][15])))
            self.tableWidget4.setItem(i,16,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][16])))
            self.tableWidget4.setItem(i,17,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][17])))
            self.tableWidget4.setItem(i,18,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][18])))
            self.tableWidget4.setItem(i,19,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][19])))
            self.tableWidget4.setItem(i,20,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][20])))
            self.tableWidget4.setItem(i,21,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][21])))
            self.tableWidget4.setItem(i,22,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][22])))
            self.tableWidget4.setItem(i,23,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][23])))
            self.tableWidget4.setItem(i,24,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][24])))
            self.tableWidget4.setItem(i,25,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][25])))
            self.tableWidget4.setItem(i,26,QTableWidgetItem(str(Pre_Basque_NumberedFreq_Analysis_list[i][26])))
        self.verticalLayout.addWidget(self.tableWidget4)

        self.tableWidget2 = QTableWidget(self)
        self.tableWidget2.setRowCount(len(Proto_BasqueUpdatedResults_LAword))
        self.tableWidget2.setColumnCount(4)
        for i in range(len(Proto_BasqueUpdatedResults_LAword)):
            self.tableWidget2.setItem(i,0,QTableWidgetItem(str(Proto_BasqueUpdatedResults_matches[i])))
            self.tableWidget2.setItem(i,1,QTableWidgetItem(str(Proto_BasqueUpdatedResults_word[i])))
            self.tableWidget2.setItem(i,2,QTableWidgetItem(str(Proto_BasqueUpdatedResults_LAword[i])))
            self.tableWidget2.setItem(i,3,QTableWidgetItem(str(Proto_BasqueUpdatedResults_Source[i])))
        self.verticalLayout.addWidget(self.tableWidget2)

        self.tableWidget5 = QTableWidget(self)
        self.tableWidget5.setRowCount(len(Post_Basque_NumberedFreq_Analysis_list))
        self.tableWidget5.setColumnCount(27)
        for i in range(len(Post_Basque_NumberedFreq_Analysis_list)):
            self.tableWidget5.setItem(i,0,QTableWidgetItem(Post_Basque_NumberedFreq_Analysis_list[i][0]))
            self.tableWidget5.setItem(i,1,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][1])))
            self.tableWidget5.setItem(i,2,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][2])))
            self.tableWidget5.setItem(i,3,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][3])))
            self.tableWidget5.setItem(i,4,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][4])))
            self.tableWidget5.setItem(i,5,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][5])))
            self.tableWidget5.setItem(i,6,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][6])))
            self.tableWidget5.setItem(i,7,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][7])))
            self.tableWidget5.setItem(i,8,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][8])))
            self.tableWidget5.setItem(i,9,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][9])))
            self.tableWidget5.setItem(i,10,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][10])))
            self.tableWidget5.setItem(i,11,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][11])))
            self.tableWidget5.setItem(i,12,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][12])))
            self.tableWidget5.setItem(i,13,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][13])))
            self.tableWidget5.setItem(i,14,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][14])))
            self.tableWidget5.setItem(i,15,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][15])))
            self.tableWidget5.setItem(i,16,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][16])))
            self.tableWidget5.setItem(i,17,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][17])))
            self.tableWidget5.setItem(i,18,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][18])))
            self.tableWidget5.setItem(i,19,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][19])))
            self.tableWidget5.setItem(i,20,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][20])))
            self.tableWidget5.setItem(i,21,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][21])))
            self.tableWidget5.setItem(i,22,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][22])))
            self.tableWidget5.setItem(i,23,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][23])))
            self.tableWidget5.setItem(i,24,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][24])))
            self.tableWidget5.setItem(i,25,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][25])))
            self.tableWidget5.setItem(i,26,QTableWidgetItem(str(Post_Basque_NumberedFreq_Analysis_list[i][26])))
        self.verticalLayout.addWidget(self.tableWidget5)

class BasquePercentageAnalysis(QWidget):
    def __init__(self, parent):
        super(BasquePercentageAnalysis, self).__init__(parent)

        self.layout = QVBoxLayout()
        self.label1 = QLabel("Number of unique matches(Pre-Basque): " + str(Unique_matches[3]))
        self.label2 = QLabel("Total Number of Words(Pre-Basque): " + str(Total_words[3]))
        self.label3 = QLabel("Percentage of Matches(Pre-Basque): " + str(Percentage_count[3]) + "%")
        self.label4 = QLabel("Number of unique matches(Proto-Basque): " + str(Unique_matches[4]))
        self.label5 = QLabel("Total Number of Words(Proto-Basque): " + str(Total_words[4]))
        self.label6 = QLabel("Percentage of Matches(Proto-Basque): " + str(Percentage_count[4]) + "%")
        self.backButton = QPushButton(self)
        self.backButton.setText("Back")

        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")
        self.layout.addWidget(self.backButton)
        self.layout.addWidget(self.label1)
        self.layout.addWidget(self.label2)
        self.layout.addWidget(self.label3)
        self.layout.addWidget(self.label4)
        self.layout.addWidget(self.label5)
        self.layout.addWidget(self.label6)

        self.setLayout(self.layout)

        self.show()

class MainMenu(QWidget):
    def __init__(self, parent=None):
        super(MainMenu, self).__init__(parent)
        self.centralwidget = QWidget(self)
        """
        Main logo
        """
        self.mainlogo = QLabel(self.centralwidget)
        self.mainlogo.setGeometry(QRect(100,40,300,200)) #100,40,300,200
        self.mainlogo.setToolTipDuration(0)
        self.mainlogo.setPixmap(QPixmap("misc/icons.png"))
        self.mainlogo.setScaledContents(True)

        self.gridLayoutWidget = QWidget(self.centralwidget)
        self.gridLayoutWidget.setGeometry(QRect(0,100,250,621))
        self.gridLayout = QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setContentsMargins(0,0,0,0)

        self.backButton = QPushButton(self)
        self.backButton.setText('Back')
        self.backButton.resize(100, 30)        
        self.backButton.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 11px;
                                          padding: 6px;
                                          background-color: rgb(165,170,225);
                                          }""")

        self.HamitoDecipherment = QPushButton(self)
        self.HamitoDecipherment.setGeometry(100,250,200,40)
        self.HamitoDecipherment.setText("Hamito-Semitic")
        self.HamitoDecipherment.setStyleSheet("font: 12pt Comic Sans MS")
        self.HamitoDecipherment.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        self.HamitoDecipherment.clicked.connect(self.Hamito_decipher1)
        
        self.AncientEgyptianDecipherment = QPushButton(self)
        self.AncientEgyptianDecipherment.setGeometry(100,320,200,40)
        self.AncientEgyptianDecipherment.setText("Ancient Egyptian")
        self.AncientEgyptianDecipherment.setStyleSheet("font: 12pt Comic Sans MS")
        self.AncientEgyptianDecipherment.clicked.connect(self.AncientEgyptian_decipher1)
        self.AncientEgyptianDecipherment.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

        
        self.AlbanianDecipherment = QPushButton(self)
        self.AlbanianDecipherment.setGeometry(100,390,200,40)
        self.AlbanianDecipherment.setText("Albanian")
        self.AlbanianDecipherment.setStyleSheet("font: 12pt Comic Sans MS")
        self.AlbanianDecipherment.clicked.connect(self.Albanian_decipher1)
        self.AlbanianDecipherment.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
        
        self.LuwianDecipherment = QPushButton(self)
        self.LuwianDecipherment.setGeometry(100,460,200,40)
        self.LuwianDecipherment.setText("Luwian")
        self.LuwianDecipherment.setStyleSheet("font: 12pt Comic Sans MS")
        self.LuwianDecipherment.clicked.connect(self.Luwian_decipher1)
        self.LuwianDecipherment.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")  
        
        self.Proto_CelticDecipherment = QPushButton(self)
        self.Proto_CelticDecipherment.setGeometry(100,530,200,40)
        self.Proto_CelticDecipherment.setText("Proto-Celtic")
        self.Proto_CelticDecipherment.clicked.connect(self.Proto_Celtic_decipher1)
        self.Proto_CelticDecipherment.setStyleSheet("font: 12pt Comic Sans MS")
        self.Proto_CelticDecipherment.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")

 
        self.AnatoliaDecipherment = QPushButton(self)
        self.AnatoliaDecipherment.setGeometry(100,600,200,40)
        self.AnatoliaDecipherment.setText("Anatolian")
        self.AnatoliaDecipherment.setStyleSheet("font: 12pt Comic Sans MS")
        self.AnatoliaDecipherment.clicked.connect(self.Anatolia_decipher1)
        self.AnatoliaDecipherment.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")


        self.BasqueDecipherment = QPushButton(self)
        self.BasqueDecipherment.setGeometry(100,670,200,40)
        self.BasqueDecipherment.setText("Basque")
        self.BasqueDecipherment.setStyleSheet("font: 12pt Comic Sans MS")
        self.BasqueDecipherment.clicked.connect(self.Basque_decipher1)
        self.BasqueDecipherment.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")  

 
        self.HittiteDecipherment = QPushButton(self)
        self.HittiteDecipherment.setGeometry(100,740,200,40)
        self.HittiteDecipherment.setText("Hittite")
        self.HittiteDecipherment.setStyleSheet("font: 12pt Comic Sans MS")
        self.HittiteDecipherment.clicked.connect(self.Hittite_decipher1)
        self.HittiteDecipherment.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")


        self.ThracianDecipherment = QPushButton(self)
        self.ThracianDecipherment.setGeometry(100,810,200,40)
        self.ThracianDecipherment.setText("Thracian")
        self.ThracianDecipherment.setStyleSheet("font: 12pt Comic Sans MS")
        self.ThracianDecipherment.clicked.connect(self.Thracian_decipher1)
        self.ThracianDecipherment.setStyleSheet("""
                                          QWidget{
                                          border-radius: 30px;
                                          border-style: outset;
                                          border-width: 4px;
                                          border-color: beige;
                                          font: bold 15px;
                                          padding: 6px;
                                          background-color: rgb(165,170,125);
                                          }""")
       
        
    def Hamito_decipher1(self):
        self.Hamito_decipher1 = HamitoDecipherMenu(self)
        self.Hamito_decipher1.show()
            
    def AncientEgyptian_decipher1(self):
        self.AncientEgyptian_decipher1 = AncientEgyptianDecipherMenu(self)
        self.AncientEgyptian_decipher1.show()

    def Albanian_decipher1(self):
        self.Albanian_decipher1 = AlbanianDecipherMenu(self)
        self.Albanian_decipher1.show()

    def Luwian_decipher1(self):
        self.Luwian_decipher1 = LuwianDecipherMenu(self)
        self.Luwian_decipher1.show()

    def Anatolia_decipher1(self):
        self.Anatolia_decipher1 = AnatoliaDecipherMenu(self)
        self.Anatolia_decipher1.show()
        
    def Basque_decipher1(self):
        self.Basque_decipher1 = BasqueDecipherMenu(self)
        self.Basque_decipher1.show()
        
    def Hittite_decipher1(self):
        self.Hittite_decipher1 = HittiteDecipherMenu(self)
        self.Hittite_decipher1.show()

    def Proto_Celtic_decipher1(self):
        self.Proto_Celtic_decipher1 = Proto_CelticDecipherMenu(self)
        self.Proto_Celtic_decipher1.show()

    def Thracian_decipher1(self):
        self.Thracian_decipher1 = ThracianDecipherMenu(self)
        self.Thracian_decipher1.show()
    

def main():
    os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"
    app = QApplication(sys.argv)
    QFontDatabase.addApplicationFont("LinearADraft1.otf")
    win = MainWindow()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
